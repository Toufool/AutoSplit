shiboken_library_soversion = "6.10"

version = "6.10.2"
version_info = (6, 10, 2, "", "")

__build_date__ = '2026-06-23T16:06:03+00:00'
__build_commit_date__ = '2026-01-29T20:20:24+00:00'
__build_commit_hash__ = '057cda38d369d042c59fd48544398cb917540718'
__build_commit_hash_described__ = 'v6.10.2'

__setup_py_package_version__ = '6.10.2'

