shiboken_library_soversion = "6.11"

version = "6.11.0a1.dev1781024091"
version_info = (6, 11, 0, "a", "1")

__build_date__ = '2026-06-09T16:57:13+00:00'



__setup_py_package_timestamp__ = '1781024091'
__setup_py_package_version__ = '6.11.0a1.dev1781024091'

