shiboken_library_soversion = "6.11"

version = "6.11.0a1.dev1781024881"
version_info = (6, 11, 0, "a", "1")

__build_date__ = '2026-06-09T17:12:38+00:00'



__setup_py_package_timestamp__ = '1781024881'
__setup_py_package_version__ = '6.11.0a1.dev1781024881'

